package FileIO5;

public class UserInfo implements Comparable{
    public String Name;
    public String Address;
    public String Phone;

    @Override
    public int compareTo(Object o) {
        if(o instanceof UserInfo){
            return ((UserInfo) o).Name.compareTo(this.Name);
        }
        return 0;
    }

    @Override
    public boolean equals(Object o){
        if(o instanceof UserInfo){
            return Name.equalsIgnoreCase(o.Name);
        }
        return null;
        
    }
}