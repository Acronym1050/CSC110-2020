package FileIO5;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.TreeSet;
import java.util.ArrayList;
import java.util.TreeSet;
import java.util.Stack;
import java.util.PriorityQueue;
import java.util.HashMap;

public class FileIO5 {

    public static void main(String... args) throws IOException{
        var fileName = "FileIO5ASS5/src/test/java/FileIO5/Sample100.csv";
            var filePath = Paths.get(fileName);
        if(!Files.exists(filePath)){
            System.out.println("The File " + fileName + " Could Not Be Found!");
        }

        var listTime = 0;
        var treeTime = 0;
        var mapTime = 0;

        var userInfos = new ArrayList<UserInfo>();
        var userInfosTree = new TreeSet<UserInfo>();
        var userInfosHash = new HashMap<Integer, UserInfo>();

        var dataElementCount = 0;
        var readStream  = Files.newBufferedReader(filePath);
        var data = readStream.readLine();

        while(data != null){
            data = readStream.readLine();
            if(data != null){
                var elements = data.split(",");
                var userInfo = new UserInfo();
                userInfo.Name = elements[0];
                userInfo.Address = elements[1];
                userInfo.Phone = elements[2];

                long start = System.currentTimeMillis();

                userInfos.add(userInfo);

                listTime += (System.currentTimeMillis() - start);

                start = System.currentTimeMillis();

                userInfosTree.add(userInfo);

                treeTime += (System.currentTimeMillis() - start);

                start = System.currentTimeMillis();

                userInfosHash.put(dataElementCount, userInfo);
                dataElementCount += 1;

                mapTime += (System.currentTimeMillis() - start);
            }
        }
        readStream.close();
        
        var outFileName = "FileIO5ASS5/src/test/java/FileIO5/data_sorted.txt";
        var outFilePath = Paths.get(outFileName);

        long start = System.currentTimeMillis();

        var writeStream = Files.newBufferedWriter(outFilePath);
       for(var userData : userInfos){
           writeStream.write(userData.Name + "|" + userData.Address + "|" + userData.Phone);
           writeStream.newLine();
       }
       writeStream.close();

       listTime += (System.currentTimeMillis() - start);

       System.out.println("Array List Time: ");
       System.out.println(String.valueOf(listTime));

       start = System.currentTimeMillis();


       var writeStreamTree = Files.newBufferedWriter(outFilePath);
       for(var userData : userInfosTree.descendingSet()){
        writeStreamTree.write(userData.Name + "|" + userData.Address + "|" + userData.Phone);
        writeStreamTree.newLine();
       }
       writeStreamTree.close();

        treeTime += (System.currentTimeMillis() - start);

        var writeStreamHash = Files.newBufferedWriter(outFilePath);
        for(int i = 0; i < dataElementCount; i++){
            var thisUser = userInfosHash.get(i);
            writeStreamHash.write(thisUser.Name + "|" + thisUser.Address + "|" + thisUser.Phone);
            writeStreamHash.newLine();
        }
        writeStreamHash.close();

        mapTime += (System.currentTimeMillis() - start);


       System.out.println("Tree Set Time:");
       System.out.println(String.valueOf(treeTime));

       System.out.println("Hash Map Time:");
       System.out.println(String.valueOf(mapTime));

       System.out.println("Average Time per Element for Array List:");
       System.out.println(String.valueOf(listTime / Long.valueOf(userInfos.size())));

       System.out.println("Average Time per Element for Tree Set:");
       System.out.println(String.valueOf(treeTime / Long.valueOf(userInfos.size())));

       System.out.println("Average Time per Element for Hash Map:");
       System.out.println(String.valueOf(mapTime / Long.valueOf(userInfos.size())));
    }
    

}
