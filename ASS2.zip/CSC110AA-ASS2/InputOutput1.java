package InputOutput1;

public class InputOutPut1 
{

    public static void main(String... args)
    {

        // Declaring my variables
        var startValue = 1;
        var endValue = 100;
        var incrementValue = 5;

        // Printing Start of Process
        System.out.println("Start of Process");

        // for statement
        for (startValue = 0; startValue <= endValue; startValue = startValue + incrementValue) {

            // Printing the Current Value
            PrintData("The Current Value", startValue);

        } // Closes Print Data

    }// Closes Main PSV

    public static void PrintData(String message, Integer value) {
        var header = "-";

        System.out.println( header.repeat(20) );
        System.out.print(message + " = ");
        System.out.println(value);

    }//Closes 2nd PSV

}//Closes Class

