package FileIO5;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.TreeSet;
import java.util.ArrayList;
import java.util.TreeSet;

public class FileIO5 {

    public static void main(String... args) throws IOException{
        var fileName = "FileIO5ASS5/src/test/java/FileIO5/Sample100.csv";
            var filePath = Paths.get(fileName);
        if(!Files.exists(filePath)){
            System.out.println("The File " + fileName + " Could Not Be Found!");
        }

        var userInfos = new TreeSet<UserInfo>();

        var dataElementCount = 0;
        var readStream  = Files.newBufferedReader(filePath);
        var data = readStream.readLine();

        while(data != null){
            data = readStream.readLine();
            if(data != null){
                var elements = data.split(",");
                var userInfo = new UserInfo();
                userInfo.Name = elements[0];
                userInfo.Address = elements[1];
                userInfo.Phone = elements[2];
                userInfos.add(userInfo);
            }
        }
        readStream.close();
        
        var outFileName = "FileIO5ASS5/src/test/java/FileIO5/data_sorted.txt";
        var outFilePath = Paths.get(outFileName);
        var writeStream = Files.newBufferedWriter(outFilePath);
        for(var userData : userInfos){
            writeStream.write(userData.Name.toUpperCase() + "|" + userData.Address + "|" + userData.Phone);
            writeStream.newLine();
        }
        writeStream.close();
    }

}
