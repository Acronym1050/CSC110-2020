//Manuel Hernandez
//CSC110AA
//August 27,2020
//ASS1-Print 10 Variables

package ASS1;

import static java.lang.System.out;

public class ASS1 
{

    public static void main(String... args) 
    {
        
        //Creating my 10 Variables.

         var num1 = 1.234;
         var num2 = 2.465;
         var num3 = 3.475;
         var num4 = 4.248;
         var num5 = 5.986;
         var num6 = 6.783;
         var num7 = 7.128;
         var num8 = 8.364;
         var num9 = 9.037;
         var num10 = 10.674;  
         
         //Printing my 10 Variables.

         out.println("These are my 10 Variables!");
         out.println(num1);
         out.println(num2);
         out.println(num3);
         out.println(num4);
         out.println(num5);
         out.println(num6);
         out.println(num7);
         out.println(num8);
         out.println(num9);
         out.println(num10);

    }
}
