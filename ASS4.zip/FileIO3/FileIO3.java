package FileIO3;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;

public class FileIO3

    {
        public static void main(String... args) throws IOException

            {
                var fileName = "FileIO3/src/main/java/FileIO3/data.txt";
                var filePath = Paths.get(fileName);

                if
                (
                    !Files.exists(filePath)
                )
                    {
                        System.out.println("The File " + fileName + " Could Not Be Found!");
                    }
                
                var userInfos = new ArrayList<String>();

                var dataElementCounts = 0;
                var readStream = Files.newBufferedReader(filePath);
                var data = readStream.readLine();

                while(data != null)
                {
                    data = readStream.readLine();

                    if
                    (
                        data != null
                    )
                        {
                            userInfos.add(data);
                        }
                }


                System.out.println("--------------NAMES------------");

                for
                (
                    var userData : userInfos
                )
                    {
                        var elements = userData.split(", ");
                        System.out.println(userData);
                    }
                    System.out.println("-----------------------------");

                
                    System.out.println("--------------ADDRESSES------------");

                    for
                    (
                        var userData : userInfos
                    )
                        {
                            var elements = userData.split(", ");
                            System.out.println(userData);
                        }
                        System.out.println("-----------------------------------");

                        System.out.println("--------------NUMBERS------------");

                        for
                        (
                            var userData : userInfos
                        )
                            {
                                var elements = userData.split(", ");
                                System.out.println(userData);
                            }
                            System.out.println("-------------------------------");

            }

    }