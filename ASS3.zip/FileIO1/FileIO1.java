//Manuel Hernandez
//CSC110-AA
//Assignment 3
//September 9, 2020

package FileIO1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileIO1
{
    public static void main(String... args) throws IOException
    {

        var fileName = "FileIO1/src/main/java/FileIO1/data.txt";
        var filePath = Paths.get(fileName);
        
        //If statement
        //Created in case that the File does not exist
        if(!Files.exists(filePath))
        {

            System.out.println("The File " + fileName + " Could Not Be Found!");

        }

        var readStream = Files.newBufferedReader(filePath);
        var data = readStream.readLine();

        //While statement
        while(data !=null)
        {

            System.out.println("1 The data " + data);
            data = readStream.readLine();

            System.out.println("2 The data " + data);
            data = readStream.readLine();

            System.out.println("3 The data " + data);
            data = readStream.readLine();

            System.out.println("4 The data " + data);
            data = readStream.readLine();

            System.out.println("5 The data " + data);
            data = readStream.readLine();

            System.out.println("6 The data " + data);
            data = readStream.readLine();

        }

    }

}